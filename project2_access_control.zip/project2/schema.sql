-- Access Control and Data Support Automation Platform
-- Database Schema

CREATE DATABASE IF NOT EXISTS access_control_db;
USE access_control_db;

-- Roles
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Permissions
CREATE TABLE IF NOT EXISTS permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    permission_name VARCHAR(100) UNIQUE NOT NULL,
    resource VARCHAR(100) NOT NULL,
    action ENUM('READ','WRITE','DELETE','ADMIN') NOT NULL,
    description TEXT
);

-- Role-Permission Mapping
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
);

-- Users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(256) NOT NULL,
    role_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    INDEX idx_role (role_id),
    INDEX idx_active (is_active)
);

-- Access Logs
CREATE TABLE IF NOT EXISTS access_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    username VARCHAR(100),
    action VARCHAR(100) NOT NULL,
    resource VARCHAR(100),
    status ENUM('SUCCESS','DENIED','ERROR') NOT NULL,
    ip_address VARCHAR(45),
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_created (created_at)
);

-- Maintenance Logs
CREATE TABLE IF NOT EXISTS maintenance_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_name VARCHAR(200) NOT NULL,
    task_type ENUM('CLEANUP','VALIDATION','BACKUP','REPORT') NOT NULL,
    status ENUM('PENDING','RUNNING','COMPLETED','FAILED') DEFAULT 'PENDING',
    result_summary TEXT,
    executed_by VARCHAR(100),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL
);

-- ─────────────────────────────────────────────
-- Seed Data
-- ─────────────────────────────────────────────
INSERT INTO roles (role_name, description) VALUES
('ADMIN', 'Full system access'),
('DEVELOPER', 'Read/write access to application resources'),
('ANALYST', 'Read-only access to reports and data'),
('SUPPORT', 'Access to support tickets and user data'),
('VIEWER', 'Read-only access across the platform');

INSERT INTO permissions (permission_name, resource, action, description) VALUES
('users:read',    'users',    'READ',   'View user list'),
('users:write',   'users',    'WRITE',  'Create/edit users'),
('users:delete',  'users',    'DELETE', 'Deactivate users'),
('users:admin',   'users',    'ADMIN',  'Full user management'),
('reports:read',  'reports',  'READ',   'View reports'),
('reports:write', 'reports',  'WRITE',  'Create reports'),
('logs:read',     'logs',     'READ',   'View system logs'),
('logs:delete',   'logs',     'DELETE', 'Purge old logs'),
('settings:admin','settings', 'ADMIN',  'Manage system settings');

-- Admin gets all permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 1, id FROM permissions;

-- Developer permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 2, id FROM permissions WHERE permission_name IN ('users:read','reports:read','reports:write','logs:read');

-- Analyst permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 3, id FROM permissions WHERE permission_name IN ('reports:read','logs:read');

-- Support permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 4, id FROM permissions WHERE permission_name IN ('users:read','users:write','logs:read');

-- Viewer permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT 5, id FROM permissions WHERE permission_name IN ('users:read','reports:read');
