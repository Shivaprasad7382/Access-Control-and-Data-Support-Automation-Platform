"""
Automated Maintenance & Log Processing Scripts
Run independently or via cron scheduler.
"""

import mysql.connector
from mysql.connector import Error
import logging
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("maintenance.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "access_control_db"
}


def get_db():
    return mysql.connector.connect(**DB_CONFIG)


def log_task(cursor, name, task_type, status, result, executed_by="cron"):
    cursor.execute("""
        INSERT INTO maintenance_logs (task_name, task_type, status, result_summary, executed_by, completed_at)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (name, task_type, status, result, executed_by, datetime.utcnow()))


# ─────────────────────────────────────────────
# Task 1: Purge old access logs
# ─────────────────────────────────────────────
def purge_old_access_logs(days=30):
    logger.info(f"[CLEANUP] Purging access logs older than {days} days...")
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            DELETE FROM access_logs WHERE created_at < NOW() - INTERVAL %s DAY
        """, (days,))
        conn.commit()
        deleted = cursor.rowcount
        result = f"Deleted {deleted} access log records older than {days} days."
        log_task(cursor, f"purge_access_logs_{days}d", "CLEANUP", "COMPLETED", result)
        conn.commit()
        logger.info(result)
    except Error as e:
        log_task(cursor, f"purge_access_logs_{days}d", "CLEANUP", "FAILED", str(e))
        conn.commit()
        logger.error(f"Purge failed: {e}")
    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────
# Task 2: Validate user data integrity
# ─────────────────────────────────────────────
def validate_user_data():
    logger.info("[VALIDATION] Running user data integrity checks...")
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    issues = []
    try:
        # Users without roles
        cursor.execute("SELECT id, username FROM users WHERE role_id IS NULL AND is_active=1")
        no_role = cursor.fetchall()
        if no_role:
            issues.append(f"{len(no_role)} active users have no role assigned.")
            logger.warning(f"Users without role: {[u['username'] for u in no_role]}")

        # Duplicate emails
        cursor.execute("""
            SELECT email, COUNT(*) AS cnt FROM users GROUP BY email HAVING cnt > 1
        """)
        dup_emails = cursor.fetchall()
        if dup_emails:
            issues.append(f"{len(dup_emails)} duplicate email(s) found.")
            logger.warning(f"Duplicate emails: {[e['email'] for e in dup_emails]}")

        # Inactive users still logged in recently
        cursor.execute("""
            SELECT id, username FROM users
            WHERE is_active=0 AND last_login >= NOW() - INTERVAL 7 DAY
        """)
        suspicious = cursor.fetchall()
        if suspicious:
            issues.append(f"{len(suspicious)} inactive user(s) have recent login activity.")
            logger.warning(f"Suspicious inactive logins: {[u['username'] for u in suspicious]}")

        result = "; ".join(issues) if issues else "All checks passed. No issues found."
        status = "COMPLETED"
        log_task(cursor, "validate_user_data", "VALIDATION", status, result)
        conn.commit()
        logger.info(f"Validation result: {result}")

    except Error as e:
        log_task(cursor, "validate_user_data", "VALIDATION", "FAILED", str(e))
        conn.commit()
        logger.error(f"Validation error: {e}")
    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────
# Task 3: Generate daily access report
# ─────────────────────────────────────────────
def generate_daily_report():
    logger.info("[REPORT] Generating daily access report...")
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT status, COUNT(*) AS count
            FROM access_logs
            WHERE created_at >= NOW() - INTERVAL 24 HOUR
            GROUP BY status
        """)
        status_summary = cursor.fetchall()

        cursor.execute("""
            SELECT username, COUNT(*) AS denied_count
            FROM access_logs
            WHERE status='DENIED' AND created_at >= NOW() - INTERVAL 24 HOUR
            GROUP BY username
            ORDER BY denied_count DESC
            LIMIT 5
        """)
        top_denied = cursor.fetchall()

        cursor.execute("""
            SELECT resource, COUNT(*) AS count
            FROM access_logs
            WHERE status='SUCCESS' AND created_at >= NOW() - INTERVAL 24 HOUR
            GROUP BY resource
            ORDER BY count DESC
        """)
        top_resources = cursor.fetchall()

        report_lines = [
            f"Daily Access Report — {datetime.utcnow().strftime('%Y-%m-%d')}",
            "Access Status Summary: " + str(status_summary),
            "Top Denied Users: " + str(top_denied),
            "Most Accessed Resources: " + str(top_resources)
        ]
        result = " | ".join(report_lines)

        log_task(cursor, "daily_access_report", "REPORT", "COMPLETED", result)
        conn.commit()
        logger.info("Daily report generated successfully.")
        return result

    except Error as e:
        log_task(cursor, "daily_access_report", "REPORT", "FAILED", str(e))
        conn.commit()
        logger.error(f"Report generation failed: {e}")
    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────
# Task 4: Auto-deactivate stale accounts
# ─────────────────────────────────────────────
def deactivate_stale_accounts(inactive_days=90):
    logger.info(f"[CLEANUP] Deactivating accounts inactive for {inactive_days}+ days...")
    conn = get_db()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            UPDATE users
            SET is_active = 0
            WHERE is_active = 1
              AND (last_login IS NULL OR last_login < NOW() - INTERVAL %s DAY)
              AND created_at < NOW() - INTERVAL %s DAY
        """, (inactive_days, inactive_days))
        conn.commit()
        deactivated = cursor.rowcount
        result = f"Deactivated {deactivated} stale account(s) (inactive >{inactive_days} days)."
        log_task(cursor, f"deactivate_stale_{inactive_days}d", "CLEANUP", "COMPLETED", result)
        conn.commit()
        logger.info(result)
    except Error as e:
        log_task(cursor, f"deactivate_stale_{inactive_days}d", "CLEANUP", "FAILED", str(e))
        conn.commit()
        logger.error(f"Stale account deactivation failed: {e}")
    finally:
        cursor.close()
        conn.close()


# ─────────────────────────────────────────────
# Run All Tasks (Cron entry point)
# ─────────────────────────────────────────────
def run_all_maintenance():
    logger.info("=" * 50)
    logger.info("Starting scheduled maintenance run...")
    logger.info("=" * 50)
    purge_old_access_logs(days=30)
    validate_user_data()
    generate_daily_report()
    deactivate_stale_accounts(inactive_days=90)
    logger.info("Maintenance run complete.")


if __name__ == "__main__":
    run_all_maintenance()
