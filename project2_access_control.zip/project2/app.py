"""
Access Control and Data Support Automation Platform
Flask + MySQL + Role-Based Access Control
"""

from flask import Flask, request, jsonify, render_template, session
from datetime import datetime
import mysql.connector
from mysql.connector import Error
import hashlib
import secrets
import logging
import traceback
import re

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

# ─────────────────────────────────────────────
# Logging Setup
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("access_control.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# DB Config
# ─────────────────────────────────────────────
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "access_control_db"
}

def get_db_connection():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        logger.error(f"DB connection failed: {e}")
        raise


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS roles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            role_name VARCHAR(50) UNIQUE NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            permission_name VARCHAR(100) UNIQUE NOT NULL,
            resource VARCHAR(100) NOT NULL,
            action ENUM('READ','WRITE','DELETE','ADMIN') NOT NULL,
            description TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS role_permissions (
            role_id INT NOT NULL,
            permission_id INT NOT NULL,
            PRIMARY KEY (role_id, permission_id),
            FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) UNIQUE NOT NULL,
            email VARCHAR(150) UNIQUE NOT NULL,
            password_hash VARCHAR(256) NOT NULL,
            role_id INT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP NULL,
            FOREIGN KEY (role_id) REFERENCES roles(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS access_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            username VARCHAR(100),
            action VARCHAR(100) NOT NULL,
            resource VARCHAR(100),
            status ENUM('SUCCESS','DENIED','ERROR') NOT NULL,
            ip_address VARCHAR(45),
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS maintenance_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            task_name VARCHAR(200) NOT NULL,
            task_type ENUM('CLEANUP','VALIDATION','BACKUP','REPORT') NOT NULL,
            status ENUM('PENDING','RUNNING','COMPLETED','FAILED') DEFAULT 'PENDING',
            result_summary TEXT,
            executed_by VARCHAR(100),
            started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL
        )
    """)

    conn.commit()
    cursor.close()
    conn.close()
    logger.info("Database initialized.")


# ─────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}:{hashed}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, hashed = stored_hash.split(":")
        return hashlib.sha256((salt + password).encode()).hexdigest() == hashed
    except Exception:
        return False


def validate_email(email: str) -> bool:
    return bool(re.match(r"^[\w\.-]+@[\w\.-]+\.\w{2,}$", email))


def log_access(user_id, username, action, resource, status, details=""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO access_logs (user_id, username, action, resource, status, ip_address, details)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (user_id, username, action, resource, status, request.remote_addr, details))
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error(f"Failed to write access log: {e}")


# ─────────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────────
@app.route("/")
def dashboard():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT COUNT(*) AS total FROM users WHERE is_active=1")
        active_users = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(*) AS total FROM roles")
        total_roles = cursor.fetchone()["total"]

        cursor.execute("SELECT COUNT(*) AS total FROM access_logs WHERE status='DENIED' AND created_at >= NOW() - INTERVAL 24 HOUR")
        denied_today = cursor.fetchone()["total"]

        cursor.execute("""
            SELECT u.username, r.role_name, u.last_login, u.is_active
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            ORDER BY u.created_at DESC LIMIT 10
        """)
        users = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template("dashboard.html",
                               active_users=active_users,
                               total_roles=total_roles,
                               denied_today=denied_today,
                               users=users)
    except Exception as e:
        logger.error(f"Dashboard error: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Role Management
# ─────────────────────────────────────────────
@app.route("/api/roles", methods=["POST"])
def create_role():
    try:
        data = request.get_json()
        if not data or "role_name" not in data:
            return jsonify({"error": "role_name is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO roles (role_name, description) VALUES (%s, %s)
        """, (data["role_name"].upper(), data.get("description", "")))
        conn.commit()
        role_id = cursor.lastrowid
        cursor.close()
        conn.close()

        logger.info(f"Role created: {data['role_name']}")
        return jsonify({"message": "Role created", "id": role_id}), 201

    except Error as e:
        if "Duplicate entry" in str(e):
            return jsonify({"error": "Role already exists"}), 409
        logger.error(f"DB error: {e}")
        return jsonify({"error": "Database error"}), 500


@app.route("/api/roles", methods=["GET"])
def get_roles():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT r.*, COUNT(rp.permission_id) AS permission_count
            FROM roles r
            LEFT JOIN role_permissions rp ON r.id = rp.role_id
            GROUP BY r.id
            ORDER BY r.role_name
        """)
        roles = cursor.fetchall()
        cursor.close()
        conn.close()

        for role in roles:
            if role.get("created_at"):
                role["created_at"] = role["created_at"].isoformat()

        return jsonify({"roles": roles}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Permission Management
# ─────────────────────────────────────────────
@app.route("/api/permissions", methods=["POST"])
def create_permission():
    try:
        data = request.get_json()
        required = ["permission_name", "resource", "action"]
        for f in required:
            if f not in data:
                return jsonify({"error": f"Missing field: {f}"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO permissions (permission_name, resource, action, description)
            VALUES (%s, %s, %s, %s)
        """, (data["permission_name"], data["resource"], data["action"].upper(), data.get("description", "")))
        conn.commit()
        perm_id = cursor.lastrowid
        cursor.close()
        conn.close()

        return jsonify({"message": "Permission created", "id": perm_id}), 201

    except Error as e:
        if "Duplicate entry" in str(e):
            return jsonify({"error": "Permission already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/roles/<int:role_id>/permissions", methods=["POST"])
def assign_permission_to_role(role_id):
    """Assign a permission to a role."""
    try:
        data = request.get_json()
        if not data or "permission_id" not in data:
            return jsonify({"error": "permission_id is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (%s, %s)
        """, (role_id, data["permission_id"]))
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"message": "Permission assigned to role"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# User Management
# ─────────────────────────────────────────────
@app.route("/api/users", methods=["POST"])
def create_user():
    """Register a new user."""
    try:
        data = request.get_json()
        required = ["username", "email", "password", "role_id"]
        for f in required:
            if f not in data:
                return jsonify({"error": f"Missing field: {f}"}), 400

        if not validate_email(data["email"]):
            return jsonify({"error": "Invalid email format"}), 400

        if len(data["password"]) < 8:
            return jsonify({"error": "Password must be at least 8 characters"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, role_id)
            VALUES (%s, %s, %s, %s)
        """, (data["username"], data["email"], hash_password(data["password"]), data["role_id"]))
        conn.commit()
        user_id = cursor.lastrowid
        cursor.close()
        conn.close()

        log_access(user_id, data["username"], "USER_CREATED", "users", "SUCCESS")
        logger.info(f"User created: {data['username']}")
        return jsonify({"message": "User created", "id": user_id}), 201

    except Error as e:
        if "Duplicate entry" in str(e):
            return jsonify({"error": "Username or email already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/users", methods=["GET"])
def get_users():
    try:
        role_id = request.args.get("role_id")
        is_active = request.args.get("is_active")

        query = """
            SELECT u.id, u.username, u.email, u.is_active, u.last_login, u.created_at,
                   r.role_name
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE 1=1
        """
        params = []
        if role_id:
            query += " AND u.role_id = %s"
            params.append(role_id)
        if is_active is not None:
            query += " AND u.is_active = %s"
            params.append(1 if is_active.lower() == "true" else 0)

        query += " ORDER BY u.created_at DESC"

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        users = cursor.fetchall()
        cursor.close()
        conn.close()

        for u in users:
            for f in ["last_login", "created_at"]:
                if u.get(f):
                    u[f] = u[f].isoformat()

        return jsonify({"users": users, "count": len(users)}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/users/<int:user_id>/role", methods=["PUT"])
def update_user_role(user_id):
    """Update a user's role (access control management)."""
    try:
        data = request.get_json()
        if not data or "role_id" not in data:
            return jsonify({"error": "role_id is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE users SET role_id = %s WHERE id = %s
        """, (data["role_id"], user_id))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "User not found"}), 404

        cursor.close()
        conn.close()

        log_access(user_id, f"user_{user_id}", "ROLE_UPDATED", "users", "SUCCESS",
                   f"New role_id: {data['role_id']}")
        return jsonify({"message": "User role updated"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/users/<int:user_id>/deactivate", methods=["PUT"])
def deactivate_user(user_id):
    """Deactivate a user account."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET is_active = 0 WHERE id = %s", (user_id,))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"error": "User not found"}), 404

        cursor.close()
        conn.close()

        log_access(user_id, f"user_{user_id}", "USER_DEACTIVATED", "users", "SUCCESS")
        return jsonify({"message": f"User {user_id} deactivated"}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Access Check
# ─────────────────────────────────────────────
@app.route("/api/access/check", methods=["POST"])
def check_access():
    """Check if a user has permission for a resource/action."""
    try:
        data = request.get_json()
        required = ["user_id", "resource", "action"]
        for f in required:
            if f not in data:
                return jsonify({"error": f"Missing field: {f}"}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Fetch user + role
        cursor.execute("""
            SELECT u.username, u.is_active, u.role_id
            FROM users u WHERE u.id = %s
        """, (data["user_id"],))
        user = cursor.fetchone()

        if not user:
            return jsonify({"allowed": False, "reason": "User not found"}), 404

        if not user["is_active"]:
            log_access(data["user_id"], user["username"], "ACCESS_CHECK", data["resource"], "DENIED", "Account inactive")
            return jsonify({"allowed": False, "reason": "Account is inactive"}), 403

        # Check permissions
        cursor.execute("""
            SELECT p.permission_name
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = %s AND p.resource = %s AND p.action = %s
        """, (user["role_id"], data["resource"], data["action"].upper()))
        permission = cursor.fetchone()

        cursor.close()
        conn.close()

        if permission:
            log_access(data["user_id"], user["username"], "ACCESS_CHECK", data["resource"], "SUCCESS",
                       f"Action: {data['action']}")
            return jsonify({"allowed": True, "permission": permission["permission_name"]}), 200
        else:
            log_access(data["user_id"], user["username"], "ACCESS_CHECK", data["resource"], "DENIED",
                       f"Action: {data['action']} not permitted")
            return jsonify({"allowed": False, "reason": "Insufficient permissions"}), 403

    except Exception as e:
        logger.error(f"Access check error: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Data Validation & Correction
# ─────────────────────────────────────────────
@app.route("/api/data/validate", methods=["GET"])
def validate_data():
    """Run data validation queries to detect issues."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Users with no role
        cursor.execute("SELECT id, username, email FROM users WHERE role_id IS NULL AND is_active=1")
        users_no_role = cursor.fetchall()

        # Users with invalid email format (basic check)
        cursor.execute("SELECT id, username, email FROM users WHERE email NOT LIKE '%@%.%'")
        invalid_emails = cursor.fetchall()

        # Duplicate emails
        cursor.execute("""
            SELECT email, COUNT(*) AS count
            FROM users
            GROUP BY email
            HAVING COUNT(*) > 1
        """)
        duplicate_emails = cursor.fetchall()

        # Roles with no users
        cursor.execute("""
            SELECT r.id, r.role_name
            FROM roles r
            LEFT JOIN users u ON u.role_id = r.id
            WHERE u.id IS NULL
        """)
        empty_roles = cursor.fetchall()

        cursor.close()
        conn.close()

        return jsonify({
            "validation_run_at": datetime.utcnow().isoformat(),
            "issues": {
                "users_without_role": users_no_role,
                "invalid_email_format": invalid_emails,
                "duplicate_emails": duplicate_emails,
                "roles_with_no_users": empty_roles
            }
        }), 200

    except Exception as e:
        logger.error(f"Validation error: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/data/correct", methods=["POST"])
def correct_data():
    """Apply a specific data correction task."""
    try:
        data = request.get_json()
        if not data or "task" not in data:
            return jsonify({"error": "task field required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        affected = 0

        if data["task"] == "deactivate_users_no_role":
            cursor.execute("UPDATE users SET is_active=0 WHERE role_id IS NULL")
            affected = cursor.rowcount

        elif data["task"] == "trim_whitespace_usernames":
            cursor.execute("UPDATE users SET username = TRIM(username) WHERE username != TRIM(username)")
            affected = cursor.rowcount

        elif data["task"] == "lowercase_emails":
            cursor.execute("UPDATE users SET email = LOWER(email) WHERE email != LOWER(email)")
            affected = cursor.rowcount

        else:
            return jsonify({"error": f"Unknown task: {data['task']}"}), 400

        conn.commit()
        cursor.close()
        conn.close()

        # Log as maintenance task
        _log_maintenance(data["task"], "VALIDATION", "COMPLETED",
                         f"Rows affected: {affected}", "system")

        return jsonify({"message": "Correction applied", "rows_affected": affected}), 200

    except Exception as e:
        logger.error(f"Data correction error: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Automated Maintenance
# ─────────────────────────────────────────────
def _log_maintenance(task_name, task_type, status, result, executed_by):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO maintenance_logs (task_name, task_type, status, result_summary, executed_by, completed_at)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (task_name, task_type, status, result, executed_by, datetime.utcnow()))
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error(f"Failed to log maintenance: {e}")


@app.route("/api/maintenance/cleanup-logs", methods=["POST"])
def cleanup_old_logs():
    """Delete access logs older than N days."""
    try:
        data = request.get_json() or {}
        days = int(data.get("older_than_days", 30))

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM access_logs WHERE created_at < NOW() - INTERVAL %s DAY
        """, (days,))
        conn.commit()
        deleted = cursor.rowcount
        cursor.close()
        conn.close()

        _log_maintenance(f"Cleanup logs older than {days} days", "CLEANUP",
                         "COMPLETED", f"Deleted {deleted} records", "system")
        logger.info(f"Log cleanup: {deleted} records deleted (>{days} days old)")
        return jsonify({"message": "Cleanup complete", "records_deleted": deleted}), 200

    except Exception as e:
        logger.error(f"Cleanup error: {traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/maintenance/report", methods=["GET"])
def maintenance_report():
    """Get recent maintenance task history."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT * FROM maintenance_logs
            ORDER BY started_at DESC LIMIT 50
        """)
        logs = cursor.fetchall()
        cursor.close()
        conn.close()

        for log in logs:
            for f in ["started_at", "completed_at"]:
                if log.get(f):
                    log[f] = log[f].isoformat()

        return jsonify({"maintenance_logs": logs, "count": len(logs)}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Access Logs
# ─────────────────────────────────────────────
@app.route("/api/access-logs", methods=["GET"])
def get_access_logs():
    try:
        status = request.args.get("status")
        user_id = request.args.get("user_id")
        limit = int(request.args.get("limit", 100))

        query = "SELECT * FROM access_logs WHERE 1=1"
        params = []
        if status:
            query += " AND status = %s"
            params.append(status.upper())
        if user_id:
            query += " AND user_id = %s"
            params.append(user_id)
        query += " ORDER BY created_at DESC LIMIT %s"
        params.append(limit)

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params)
        logs = cursor.fetchall()
        cursor.close()
        conn.close()

        for log in logs:
            if log.get("created_at"):
                log["created_at"] = log["created_at"].isoformat()

        return jsonify({"access_logs": logs, "count": len(logs)}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
# Error Handlers
# ─────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(e):
    logger.critical(f"Unhandled exception: {e}")
    return jsonify({"error": "Internal server error"}), 500


# ─────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5001)
